from Classes.lab_3.ArtGenerator import ArtGenerator
from Classes.lab_4.Classes.fonts import fonts


class CustomArt(ArtGenerator):
    def __init__(self, **kwargs):
        # Initialize the CustomArt with default font 'standard'
        super().__init__(**kwargs)
        self._font = 'standard'

    def _custom_justify(self):
        # Apply custom justification based on the specified 'justify' parameter
        message = self.message
        if self.justify == 'center':
            message = message.rjust(20, ' ')
        elif self.justify == 'right':
            message = message.rjust(40)
        elif self.justify == 'left':
            message = message.ljust(0, ' ')
        return message

    def _create(self, **kwargs):
        # Create custom ASCII art using the specified font and justification
        if 'font' in kwargs:
            font = kwargs['font']
        else:
            font = self._font
        # Get the font definition from the 'fonts' module
        font = fonts.get(font)
        self._direction_message = self._custom_justify()
        art = []
        max_lines = max(len(font.get(letter, '').split('\n')) for letter in self._direction_message)

        output = self.generate_art(max_lines, font, art)
        return output

    # Iterate through each line of the ASCII art
    def generate_art(self, max_lines, font, art):
        for line_num in range(max_lines):
            line = ""
            # Iterate through each letter in the message
            for letter in self._direction_message:
                letter_lines = font.get(letter, '').split('\n')
                # Check if the current line number is within the range of the letter lines
                if line_num < len(letter_lines):
                    # Apply justification based on the specified 'justify' parameter
                    if self.justify == 'left':
                        line += letter_lines[line_num].ljust(len(letter_lines[0]) + 1)
                    elif self.justify == 'center':
                        line += letter_lines[line_num].center(len(letter_lines[0]) + 1)
                    elif self.justify == 'right':
                        line += letter_lines[line_num].rjust(len(letter_lines[0]) + 1)
                    else:
                        line += letter_lines[line_num].rjust(len(letter_lines[0]) + 1)
                else:
                    # If the line number is outside the range, add spaces
                    line += ' ' * (len(letter_lines[0]) + 1)
            # Add the line to the art
            art.append(line)
        # Join the lines to form the final output
        output = '\n'.join(art)
        return output
