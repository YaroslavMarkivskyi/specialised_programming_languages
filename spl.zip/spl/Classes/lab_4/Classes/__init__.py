from Classes.lab_4.Classes.CustomArt import CustomArt
from Classes.lab_4.Classes.fonts import FONTS
