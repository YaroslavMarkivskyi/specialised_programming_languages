from .Classes import *
from Classes.lab_3.justifies import JUSTIFIES

