from Classes.lab_1.ConsoleCalculator import ConsoleCalculator as ConsoleLab_1
from Classes.lab_2.ConsoleCalculator import ConsoleCalculator
from Classes.lab_3.ArtConsole import ArtConsole
from Classes.lab_4.CustomArtConsole import CustomArtConsole
from Classes.lab_5.ConsoleFigure import ConsoleFigure
from Classes.lab_6.ConsoleTest import ConsoleTest
from Classes.lab_7.ConsoleAPI import ConsoleAPI
from Classes.lab_8.ConsoleCSV import ConsoleCSV


class Menu:
    def __init__(self):
        self.menu_1 = ConsoleLab_1()
        self.menu_2 = ConsoleCalculator()
        self.menu_3 = ArtConsole()
        self.menu_4 = CustomArtConsole()
        self.menu_5 = ConsoleFigure()
        self.menu_6 = ConsoleTest()
        self.menu_7 = ConsoleAPI()
        self.menu_8 = ConsoleCSV()

    def call(self, menu):

        self.menu_1.run()
        self.menu_2.run()
        self.menu_3.run()
        self.menu_4.run()
        self.menu_5.run()
        self.menu_6.run()
        self.menu_7.run()
        self.menu_8.run()


menu = {
    'Lab_1': None,
    'Lab_2': None,
    'Lab_3': None,
    'Lab_4': None,
    'Lab_5': None,
    'Lab_6': None,
    'Lab_7': None,
    'Lab_8': None,
    'Exit': None,



}
