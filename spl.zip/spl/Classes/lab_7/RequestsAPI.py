import csv
import json

import requests
from prettytable import PrettyTable
from colorama import Style, Fore


class RequestsAPI:

    def __init__(self, **kwargs):
        self._result = PrettyTable()
        self._site = kwargs['site'] if 'site' in kwargs else ''
        self._params = kwargs['params'] if 'params' in kwargs else {}
        self._response = requests.get(self._site)
        self._data = self._response.json()
        self._history = []

        self._color = Fore.CYAN
        self._font = Style.NORMAL
        self._reset = Style.RESET_ALL

    @property
    def font(self):
        return self._font

    @font.setter
    def font(self, value):
        self._font = value

    @property
    def site(self):
        return self._site

    @site.setter
    def site(self, value):
        self._site = value

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, value):
        self._color = value

    @property
    def params(self):
        return self._params

    @params.setter
    def params(self, value):
        self._params = value

    def get_headers(self, data=None):
        if not data:
            data = self._data
        if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
            return data[0].keys()
        elif isinstance(data, dict):
            return data.keys()
        else:
            raise ValueError("Непідтримуваний формат даних")

    def get_table(self):
        table = PrettyTable()
        field_names = []
        if isinstance(self._data, list) and len(self._data) > 0 and isinstance(self._data[0], dict):
            headers = self._data[0].keys()

            for row in self._data:
                table.add_row(row.values(), divider=True)
        elif isinstance(self._data, dict):
            headers = self._data.keys()
            table.add_row(self._data.values(),  divider=True)
        else:
            raise ValueError("Непідтримуваний формат даних")
        table.field_names = headers
        for field_name in table.field_names:
            field_names.append(self._color + self._font + field_name + self._reset)
        table.field_names = field_names
        return table

    @staticmethod
    def __get_custom_headers(custom_headers):
        headers = []
        for custom_header in custom_headers:
            headers.append(custom_header.get('header'))

        return headers

    def get_custom_table(self, custom_headers):
        table = PrettyTable()
        new_headers = self.__get_custom_headers(custom_headers)
        new_data = []
        if isinstance(self._data, list) and len(self._data) > 0 and isinstance(self._data[0], dict):
            for data in self._data:
                dicts = {}
                for key, value in data.items():
                    if key in new_headers:
                        dicts[key] = value
                new_data.append(dicts)

            for row in new_data:
                table.add_row(row.values(),  divider=True)
            headers = new_data[0].keys()

        elif isinstance(self._data, dict):

            headers = self._data.keys()
            table.add_row(self._data.values(),  divider=True)
        else:
            raise ValueError("Непідтримуваний формат даних")
        table.field_names = headers
        return table, new_data

    def set_custom_headers(self, custom_headers: list[dict], data):
        new_headers = []

        user_headers = [item.get('header') for item in custom_headers]

        old_headers = self.get_headers(data)

        for old_header in old_headers:
            if old_header in user_headers:
                new_header = self.__get_custom_header(old_header, custom_headers)
            else:
                new_header = old_header
            new_headers.append(new_header)
        return new_headers

    def __get_custom_header(self, old_header, custom_headers):
        new_header = ''
        for header in custom_headers:
            if header.get('header') == old_header:
                new_header = self.set_style(header.get('header'), header.get('color'), header.get('font'))
                break
        return new_header

    def set_style(self, header, color, font):
        return color + font + header + self._reset

    def visualize_table(self, custom_headers=None):
        table, data = self.get_custom_table(custom_headers)
        field_names = []
        if custom_headers:
            field_names = self.set_custom_headers(custom_headers, data)
        else:
            for field_name in table.field_names:
                field_names.append(self._color + self._font + field_name + self._reset)
        table.field_names = field_names
        return table

    def save_to_json(self, filename):
        filename = self._add_extension(filename, "json")
        with open(filename, "w") as json_file:
            json.dump(self._data, json_file, indent=2)

    def save_to_csv(self, filename):
        filename = self._add_extension(filename, "csv")
        csv_columns = self._data[0].keys()
        with open(filename, "w", newline="") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=csv_columns)
            writer.writeheader()
            for row in self._data:
                writer.writerow(row)

    def save_to_txt(self, filename):
        filename = self._add_extension(filename, "txt")
        with open(filename, "w") as txt_file:
            for row in self._data:
                txt_file.write(f"{row}\n")

    @staticmethod
    def _add_extension(filename, default_extension):
        if not filename.endswith(f".{default_extension}"):
            filename += f".{default_extension}"
        return filename

# site = 'https://jsonplaceholder.typicode.com/users'
# params = {}
#
# response = RequestsAPI(site=site, params=params)
#
# print(response.get_table())
# print(response.visualize_table())
