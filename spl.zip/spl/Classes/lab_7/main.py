from  Classes.lab_7.ConsoleInterface import ConsoleRequestsApi

req = ConsoleRequestsApi()
req.run()

