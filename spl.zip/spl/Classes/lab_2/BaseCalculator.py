from Classes.lab_2.operators import OPERATORS
import math


# BaseCalculator class for basic mathematical operations
class BaseCalculator:

    # Constructor with optional keyword arguments for initialization
    def __init__(self, **kwargs):
        self._num_1 = kwargs['num_1'] if 'num_1' in kwargs else 0
        self._num_2 = kwargs['num_2'] if 'num_2' in kwargs else 0
        self._operator = kwargs['operator'] if 'operator' in kwargs else '+'
        self._custom_round = kwargs['custom_round'] if 'custom_round' in kwargs else 0
        self._result = 0

    # Number validation method
    @classmethod
    def _number_validate(cls, num):
        try:
            num = float(num)
            return num
        except ValueError:
            raise ValueError(f"Parameter '{num}' is not a number")

    # Operator validation method
    @classmethod
    def _operator_validate(cls, symbol):
        if symbol not in OPERATORS:
            raise TypeError(f"Operator is not in {OPERATORS}!")
        else:
            return symbol

    # Basic mathematical operations

    def _add(self):
        return self._num_1 + self._num_2

    def _sub(self):
        return self._num_1 - self._num_2

    def _mul(self):
        return self._num_1 * self._num_2

    def _div(self):
        if self._num_2 != 0:
            return self._num_1 / self._num_2
        else:
            raise ZeroDivisionError("Division by zero")

    def _deg(self):
        return self._num_1 ** self._num_2

    def _rem(self):
        if self._num_2 != 0:
            return self._num_1 % self._num_2
        else:
            raise ZeroDivisionError("Division by zero")

    def _square(self):
        if self._num_1 >= 0:
            return math.sqrt(self._num_1)
        else:
            raise ArithmeticError("Square root of a negative number")

    # Calculator function to perform the calculation based on the selected operator
    def calc(self):
        if self._operator == '+':
            self._result = round(self._add(), self._custom_round)
        elif self._operator == '-':
            self._result = round(self._sub(), self._custom_round)
        elif self._operator == '*':
            self._result = round(self._mul(), self._custom_round)
        elif self._operator == '/':
            self._result = round(self._div(), self._custom_round)
        elif self._operator == '^':
            self._result = round(self._deg(), self._custom_round)
        elif self._operator == '√':
            self._result = round(self._square(), self._custom_round)
        elif self._operator == '%':
            self._result = round(self._rem(), self._custom_round)

    # String representation of the calculator instance

    def __str__(self):
        self.calc()
        if self._operator == '√':
            return f"{self._operator} {self._num_1} = {self._result}"
        else:
            return f"{self._num_1} {self._operator} {self._num_2} = {self._result}"

    # Property and setter methods for num_1, num_2, operator, and custom_round

    @property
    def result(self):
        return self._result

    @property
    def custom_round(self):
        return self._custom_round

    @custom_round.setter
    def custom_round(self, value):
        self._custom_round = value

    @property
    def num_1(self):
        return self._num_1

    @num_1.setter
    def num_1(self, value):
        self._num_1 = value

    @property
    def num_2(self):
        return self._num_2

    @num_2.setter
    def num_2(self, value):
        self._num_2 = value

    @property
    def operator(self):
        return self._operator

    @operator.setter
    def operator(self, value):
        self._operator = value
