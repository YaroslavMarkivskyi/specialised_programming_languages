

class ConsoleCSV:
    def run(self):
        pass
