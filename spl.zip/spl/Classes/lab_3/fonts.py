

FONTS = {
            '1': "standard",
            '2': "slant",
            '3': "big",
            '4': "block",
            '5': "bubble",
            '6': "digital",
            '7': "isometric1",
            '8': "isometric2",
            '9': "letters",
            '10': "script",
            '11': "shadow",
            '12': "starwars",
        }