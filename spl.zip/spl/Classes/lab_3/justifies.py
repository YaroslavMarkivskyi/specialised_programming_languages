

JUSTIFIES = {
            '1': 'center',
            '2': 'right',
            '3': 'left',
        }
