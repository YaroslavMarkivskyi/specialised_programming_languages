import pyfiglet
from Classes.lab_3.ScalableArt import ScalableArt


class ArtGenerator:

    # Initialize default values or use provided values
    def __init__(self, **kwargs):
        self._ascii_art = ''
        self._message = kwargs.get('message', '')
        self._height = kwargs.get('height', 1)
        self._width = kwargs.get('width', 1)
        self._justify = kwargs.get('direction', 'auto')
        self._font = kwargs.get('font', 'standard')
        self._symbol = kwargs.get('symbol', '*')

    # Replace specific characters in the art with user-defined symbols
    def custom_font(self):
        if self._font != 'banner3':
            self.create_art(font='banner3')
        for original_char, user_char in zip("#/", self._symbol):
            self._ascii_art = self._ascii_art.replace(original_char, user_char)

    # Create ASCII art using pyfiglet library
    def create_art(self, **kwargs):
        font = kwargs.get('font', self._font)
        art = pyfiglet.Figlet(font=font, justify=self._justify)
        self._ascii_art = art.renderText(self._message)

    # Scale the ASCII art using the ScalableArt class
    def scaling(self):
        self.create_art()
        self._ascii_art = ScalableArt(self._ascii_art, self._height, self._width).generate_zoom_art()

    def __str__(self):
        return self._ascii_art

    # Properties and setters for various attributes

    @property
    def message(self):
        return self._message

    @message.setter
    def message(self, value):
        self._message = value

    @property
    def justify(self):
        return self._justify

    @justify.setter
    def justify(self, value):
        self._justify = value

    @property
    def font(self):
        return self._font

    @font.setter
    def font(self, value):
        self._font = value

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, value):
        self._width = value

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, value):
        self._height = value

    @property
    def symbol(self):
        return self._symbol

    @symbol.setter
    def symbol(self, value):
        self._symbol = value

    @property
    def ascii_art(self):
        return self._ascii_art
