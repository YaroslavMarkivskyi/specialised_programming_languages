class ScalableArt:
    # Initialize the ScalableArt with the provided art, height, and width
    def __init__(self, art: str, height: int, width: int):
        self.art = art
        self.update_height = height
        self.update_width = width

    # Generate scaled ASCII art based on the provided height and width
    def generate_zoom_art(self) -> str:
        lines = self.__generate_art_list(self.art)
        len_base_art = len(lines)
        len_base_art_line = len(max(lines, key=len))
        scale = self.__get_scale(self.update_height, self.update_width, len_base_art, len_base_art_line)
        new_art_list = self.__get_new_art_list(lines, scale)
        art = self.__convert_list_to_art(new_art_list)
        return art

    # Convert the ASCII art string into a list of lines
    @staticmethod
    def __generate_art_list(art: str) -> list:
        line = ''
        lines = []
        for char in art:
            if char != '\n':
                line += char
            else:
                lines.append(line)
                line = ''
        return lines

    # Calculate the scaling factor based on the provided dimensions
    @staticmethod
    def __get_scale(base_height: int, base_width: int, update_height: int, update_width: int) -> int:
        square_base = base_height * base_width
        square_update = update_height * update_width
        scale = round(max(square_base, square_update) / min(square_base, square_update))
        return scale

    # Convert a list of lines back into a single string with line breaks
    @staticmethod
    def __convert_list_to_art(line_list: list) -> str:
        result = ''
        for line in line_list:
            result += line + '\n'
        return result

    # Scale each line in the ASCII art list
    @staticmethod
    def __get_new_art_list(lines: list, scale: int) -> list:
        result = []
        for line in lines:
            new_line = ''
            for char in line:
                new_line += char * scale
            result.extend([new_line] * scale)
        return result
