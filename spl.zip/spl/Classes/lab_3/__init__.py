from Classes.lab_3.ArtGenerator import ArtGenerator
from Classes.lab_3.fonts import FONTS
from Classes.lab_3.justifies import JUSTIFIES
