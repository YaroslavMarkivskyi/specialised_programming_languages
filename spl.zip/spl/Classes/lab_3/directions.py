

DIRECTIONS = {
            'LTR': 'left-to-right',
            'RTl': 'right-to-left',
        }
