FIGURES = {
    '1': 'Pyramid',
    '2': 'Parallelepiped'
}

FIGURES_TYPE = {
    '1': '2D',
    '2': '3D'
}
