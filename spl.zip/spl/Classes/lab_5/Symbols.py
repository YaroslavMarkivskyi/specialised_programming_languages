SYMBOLS = {
        'corner': '+',
        'horizontal': '-',
        'vertical': '|',
        'inclined': '/',
        'space': ' ',
        'nothing': '',
}
# '�'