from Classes.lab_5.Figure import Figure
from Classes.lab_5.Parallelepiped import Parallelepiped
from Classes.lab_5.Pyramid import Pyramid
from Classes.lab_5.Figures import FIGURES, FIGURES_TYPE
