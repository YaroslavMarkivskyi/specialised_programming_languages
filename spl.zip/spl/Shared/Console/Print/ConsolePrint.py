

class ConsolePrint:
    def __init__(self, **kwargs):
        self.__output = kwargs['output'] if 'output' in kwargs else ''

    def print(self):
        print(self.__output)

    @property
    def output(self) -> str:
        return self.__output

    @output.setter
    def output(self, output) -> None:
        self.__output = output
