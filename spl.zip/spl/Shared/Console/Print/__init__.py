from .ConsolePrint import ConsolePrint

from .Command.PrintCommand import PrintCommand
from .Command.SetOutputCommand import SetOutputCommand
