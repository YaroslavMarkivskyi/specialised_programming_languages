from Shared.Console.Input.Command.MethodCommands import *
from Shared.Console.Input.Command.SetCommands import *
