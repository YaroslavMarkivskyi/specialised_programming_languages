from Shared.Console.Print.ConsolePrint import ConsolePrint
from colorama import Style


class InputValue:

    def __init__(self, **kwargs) -> None:
        self._message = kwargs['message'] if 'message' in kwargs else ''
        self._value = ''
        self.__print = ConsolePrint()

    def input_text(self) -> None:
        self._value = input(f"{self._message}: ")

    def input_int_number(self) -> None:
        self._value = int(input(f"{self._message}: "))

    def input_float_number(self) -> None:
        self._value = float(input(f"{self._message}: "))

    def input_bool(self) -> None:
        self._value = bool(input(f"{self._message}: "))

    def convert__string_object(self, message: str) -> None:
        self._value = message

    def select_object_with_dict(self, dictionary: dict):
        self.__print.output = f"{self._message}:"
        self.__print.print()
        for key, value in dictionary.items():
            self.__print.output = f"{key}: {value}" + Style.RESET_ALL
            self.__print.print()
        param = input('Input key of dictionary: ')
        self._value = dictionary.get(param, '')

    def __str__(self) -> str:
        return self._value

    @property
    def message(self) -> str:
        return self._message

    @message.setter
    def message(self, message) -> None:
        self._message = message

    @property
    def value(self):
        return self._value
