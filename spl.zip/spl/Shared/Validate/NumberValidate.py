

class NumberValidate:

    def __init__(self, number: int):
        self.number = self.validate(number)

    @classmethod
    def validate(cls, number: int):
        try:
            return int(number)
        except ValueError():
            raise ValueError("Number is not int")



