from Shared.Command.ComplexCommand import ComplexCommand

from Shared.Console.Input import InputValue, InputBoolCommand
from Shared.StylizeSymbol import StylizeSymbol, SetMessageCommand, GenerateCustomLineCommand
from Shared.Console.Print import ConsolePrint, SetOutputCommand, PrintCommand


class BuilderMenu:
    def __init__(self):
        self._result = ''
        self._stylize_symbols = StylizeSymbol()
        self._output = ConsolePrint()
        self._menu_builder = ComplexCommand()
        self._subsystem_status = InputValue()

    def _configure_lab_subsystem(self):
        pass

    def _configure_save_subsystem(self):
        pass

    def _convert_obj_to_result_subsystem(self):
        pass

    def _configure_output_subsystem(self):
        self._menu_builder.instant_command(SetMessageCommand(self._stylize_symbols, self._result))
        self._menu_builder.instant_command((GenerateCustomLineCommand(self._stylize_symbols)))
        self._menu_builder.instant_command(SetOutputCommand(self._output, self._stylize_symbols))
        self._menu_builder.instant_command(PrintCommand(self._output))

    def _configure_check_subsystem(self):
        self._menu_builder.instant_command(InputBoolCommand(self._subsystem_status))

    def run_menu(self):
        self._configure_lab_subsystem()
        self._convert_obj_to_result_subsystem()
        self._configure_output_subsystem()
        self._configure_save_subsystem()
