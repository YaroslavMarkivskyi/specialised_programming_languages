import os
import json
import csv


class DataSaver:
    def __init__(self, **kwargs):
        self.__lab = kwargs['package_name'] if 'package_name' in kwargs else 'trash'
        self.file_name = kwargs['filename'] if 'filename' in kwargs else 'trash'
        self.__data = 'Data'

    def get_project_path(self):
        script_path = os.path.dirname(os.path.abspath(__file__))
        project_path = os.path.dirname(os.path.dirname(script_path))
        project_path_1 = os.path.dirname(project_path)

        data_path = os.path.join(project_path_1, self.__data, self.__lab)

        os.makedirs(data_path, exist_ok=True)

        return data_path

    def save_txt(self, text_data):
        file_path = os.path.join(self.get_project_path(), self.file_name + ".txt")

        with open(file_path, 'w') as file:
            file.write(text_data)

    def save_json(self, json_data):
        file_path = os.path.join(self.get_project_path(), self.file_name + ".json")

        with open(file_path, 'w') as file:
            json.dump(json_data, file)

    def save_csv(self, csv_data):
        file_path = os.path.join(self.get_project_path(), self.file_name + ".csv")

        with open(file_path, 'w', newline='') as file:
            csv_writer = csv.writer(file)
            csv_writer.writerows(csv_data)


# saver = DataSaver(package_name="Lab_1", file_name="saved_data")
# text_data = "Це текст для збереженgjgня у файлі txt."
# json_data = {"ключ": "значення"}
# csv_data = [["Спостереження 1", "Значення 1"], ["Спостереження 2", "Значення 2"]]
