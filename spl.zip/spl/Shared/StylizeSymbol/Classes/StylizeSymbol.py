from Shared.Constants.colors import COLORS


class StylizeSymbol:

    def __init__(self, **kwargs):
        self.__line = kwargs['line'] if 'line' in kwargs else ''
        self.__color = kwargs['color'] if 'color' in kwargs else COLORS.get('RESET')
        self.__font = kwargs['font'] if 'font' in kwargs else ''
        self.__result = ''

    def generate_custom_line(self):
        self.__result = self.__color + self.__font + self.__line + COLORS.get('RESET')

    def __str__(self):
        return self.__result

    # GET result
    @property
    def result(self):
        return self.__result

    # GETTER/SETTER line
    @property
    def line(self):
        return self.__line

    @line.setter
    def line(self, line):
        self.__line = line

    # GETTER/SETTER color
    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, color):
        self.__color = color

    # GETTER/SETTER line
    @property
    def font(self):
        return self.__font

    @font.setter
    def font(self, font):
        self.__font = font
