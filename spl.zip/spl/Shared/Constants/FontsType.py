
FONTS_TYPE = {
    '1': 'Base Fonts',
    '2': 'Custom font'
}
