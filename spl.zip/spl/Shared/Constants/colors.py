from colorama import Fore, Back, Style


COLORS = {
        'BLACK': Fore.BLACK,
        'RED': Fore.RED,
        'GREEN': Fore.GREEN,
        'YELLOW': Fore.YELLOW,
        'BLUE': Fore.BLUE,
        'MAGENTA': Fore.MAGENTA,
        'CYAN': Fore.CYAN,
        'WHITE': Fore.WHITE,
        'RESET': Style.RESET_ALL,
    }

BACKGROUND_COLORS = {
        'BLACK': Back.BLACK,
        'RED': Back.RED,
        'GREEN': Back.GREEN,
        'YELLOW': Back.YELLOW,
        'BLUE': Back.BLUE,
        'MAGENTA': Back.MAGENTA,
        'CYAN': Back.CYAN,
        'WHITE': Back.WHITE,
    }
#
# colors = {
#         '1': [Fore.BLACK, Fore.BLACK + 'BLACK' + Fore.RESET],
#         '2': [Fore.RED, Fore.RED + 'RED' + Fore.RESET],
#         '3': [Fore.GREEN, Fore.GREEN + 'GREEN' + Fore.RESET],
#         '4': [Fore.YELLOW, Fore.YELLOW + 'YELLOW' + Fore.RESET],
#         '5': [Fore.BLUE, Fore.BLUE + 'BLUE' + Fore.RESET],
#         '6': [Fore.MAGENTA, Fore.MAGENTA + 'MAGENTA' + Fore.RESET],
#         '7': [Fore.CYAN, Fore.CYAN + 'CYAN' + Fore.RESET],
#         '8': [Fore.WHITE, Fore.WHITE + 'WHITE' + Fore.RESET],
#         '9': [Fore.RESET, Fore.RESET + 'RESET' + Fore.RESET],
# }
#
#
# print(colors.get('1')[1])
