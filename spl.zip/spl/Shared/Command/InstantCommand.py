from typing import List

from Shared.Command.Command import Command


class InstantCommand:

    def __init__(self):
        self.history: List[Command] = []

    def add_command(self, command: Command) -> None:
        self.history.append(command)

    def run(self, command: Command) -> None:
        if not self.history:
            print("")
        else:
            for executor in self.history:
                executor.execute()
        self.history.clear()
