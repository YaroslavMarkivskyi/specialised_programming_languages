from typing import List

from Shared.Command.Command import Command


class ComplexCommand:

    def __init__(self):
        self.history: List[Command] = []

    def add_command(self, command: Command) -> None:
        self.history.append(command)

    @staticmethod
    def instant_command(command: Command) -> None:
        command.execute()

    def run(self) -> None:
        if self.history:
            for executor in self.history:
                executor.execute()
        self.history.clear()
