import sys

from UI.Menu import main

if __name__ == '__main__':
    sys.exit(main())
