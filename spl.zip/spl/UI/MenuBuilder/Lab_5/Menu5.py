

class Menu5:
    def __init__(self):
        pass

    def run(self):
        pass

"""
size(x,y,z)
color
type
view
scale
custom square color
save
import
"""