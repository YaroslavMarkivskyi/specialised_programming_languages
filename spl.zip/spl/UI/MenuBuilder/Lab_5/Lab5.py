from Classes.lab_5 import *
from Shared.BuilderMenu.BuilderMenu import BuilderMenu
from UI.MenuBuilder.Lab_5.Commands import *
from Shared.Console.Input import (InputValue, SelectObjectWithDictCommand,
                                  SetInputMessageCommand, InputIntNumberCommand)

from Shared.Constants import BACKGROUND_COLORS, COLORS


class MenuLab5(BuilderMenu):
    def __init__(self):
        super().__init__()
        self.__figure_type = InputValue(message="Choose figure")
        self.__figures_type = InputValue()
        self.__figure = Figure()
        self.__size_x = InputValue(message='Input size x')
        self.__size_y = InputValue(message='Input size y')
        self.__size_z = InputValue(message='Input size z')
        self.__color_area_1 = InputValue(message='Choose area 1')
        self.__color_area_2 = InputValue(message='Choose area 2')
        self.__color_area_3 = InputValue(message='Choose area 3')
        self.__border_color = InputValue(message='Choose border color')
        self.__shadow_color = InputValue(message='Choose shadow color')
        self.__scaling = InputValue(message='Input scaling')

        self.__subsystem_status = InputValue(message='Do you want to ...')

    def _configure_lab_subsystem(self):
        self.__configure_figure_subsystem()
        self.__configure_area_color_subsystem()
        self.__configure_scaling_subsystem()
        self.__configure_build_figure_subsystem()

    def __configure_figure_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__figure_type, FIGURES))
        self.__configure_size_subsystem()
        if self.__figure_type.value == 'Parallelepiped':
            self.__configure_parallelepiped_subsystem()
        elif self.__figure_type.value == 'Pyramid':
            self.__configure_pyramid_subsystem()

    def __configure_parallelepiped_subsystem(self):
        self.__figure = Parallelepiped()
        self._menu_builder.instant_command(SetSizeXCommand(self.__figure, self.__size_x.value))
        self._menu_builder.instant_command(SetSizeYCommand(self.__figure, self.__size_y.value))
        self._menu_builder.instant_command(SetSizeZCommand(self.__figure, self.__size_z.value))

    def __configure_pyramid_subsystem(self):
        self.__figure = Pyramid()
        self._menu_builder.instant_command(SetSizeXCommand(self.__figure, self.__size_x.value))
        self._menu_builder.instant_command(SetSizeYCommand(self.__figure, self.__size_y.value))
        self._menu_builder.instant_command(SetSizeZCommand(self.__figure, self.__size_z.value))

    def __configure_size_subsystem(self):
        self._menu_builder.instant_command(InputIntNumberCommand(self.__size_x))
        self._menu_builder.instant_command(InputIntNumberCommand(self.__size_y))
        self._menu_builder.instant_command(InputIntNumberCommand(self.__size_z))

    def __configure_scaling_subsystem(self):
        self._menu_builder.instant_command(SetInputMessageCommand(self._subsystem_status,
                                                                  "Do you want to set scaling (1/0:)"))
        self._configure_check_subsystem()  # scaling
        if self._subsystem_status.value:
            self._menu_builder.instant_command((InputIntNumberCommand(self.__scaling)))
            self._menu_builder.instant_command(SetScalingCommand(self.__figure, self.__scaling.value))

    def _convert_obj_to_result_subsystem(self):
        self._result = self.__figure.__str__()

    def __configure_area_color_subsystem(self):
        self._menu_builder.instant_command(SetInputMessageCommand(self._subsystem_status,
                                                                  "Do you want to set colors (1/0:)"))
        self._configure_check_subsystem()  # Area, Border, Shadow, color
        if self._subsystem_status.value:
            self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__color_area_1, BACKGROUND_COLORS))
            self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__color_area_2, BACKGROUND_COLORS))
            self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__color_area_3, BACKGROUND_COLORS))
            self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__border_color, COLORS))
            self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__shadow_color, BACKGROUND_COLORS))

            self._menu_builder.instant_command((SetColorArea1Command(self.__figure, self.__color_area_1.value)))
            self._menu_builder.instant_command((SetColorArea2Command(self.__figure, self.__color_area_2.value)))
            self._menu_builder.instant_command((SetColorArea3Command(self.__figure, self.__color_area_3.value)))
            self._menu_builder.instant_command((SetSymbolColorCommand(self.__figure, self.__border_color.value)))
            self._menu_builder.instant_command((SetShadowColorCommand(self.__figure, self.__shadow_color.value)))

    def __configure_build_figure_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self.__figures_type, FIGURES_TYPE))
        if self.__figures_type.value == '2D':
            self._menu_builder.instant_command(Build2DCommand(self.__figure))
        else:
            self._menu_builder.instant_command(Build3DCommand(self.__figure))


menu_facade = MenuLab5()
menu_facade.run_menu()
