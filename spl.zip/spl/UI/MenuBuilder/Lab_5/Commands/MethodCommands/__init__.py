from UI.MenuBuilder.Lab_5.Commands.MethodCommands.Build3DCommand import Build3DCommand
from UI.MenuBuilder.Lab_5.Commands.MethodCommands.Build2DCommand import Build2DCommand
