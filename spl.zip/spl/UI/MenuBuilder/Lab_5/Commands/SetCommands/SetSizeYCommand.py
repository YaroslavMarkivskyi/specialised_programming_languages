from Shared.Command.Command import Command
from Classes.lab_5.Figure import Figure


class SetSizeYCommand(Command):
    """
    Command can implement create art .
    """

    def __init__(self, executor: Figure, size_y: int):
        self.__executor = executor
        self.__size_y = size_y

    def execute(self) -> None:
        self.__executor.size_y = self.__size_y
