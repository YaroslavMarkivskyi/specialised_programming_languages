from Classes.lab_2.BaseCalculator import *
from Shared.Command.Command import Command


class CalcCommand(Command):
    """
    Command can implement input text .
    """

    def __init__(self, executor: BaseCalculator):
        self.__executor = executor

    def execute(self) -> None:
        self.__executor.calc()
