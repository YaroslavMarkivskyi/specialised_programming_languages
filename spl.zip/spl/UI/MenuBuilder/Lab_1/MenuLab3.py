from Classes.lab_3.Command.MethodCommands.ArtScalingCommand import ArtScalingCommand
from Classes.lab_3.Command.SetCommands.ArtSetMessageCommand import ArtSetMessageCommand
from Shared.Console.UserInput.Command.InputTextCommand import InputTextCommand
from Shared.Console.UserInput.InputValue import InputValue
from Classes.lab_3.ArtGenerator import ArtGenerator
from Shared.Command.ComplexCommand import ComplexCommand


class MenuLabOne:

    def __init__(self):
        self._art = ArtGenerator()

        # self.__message = InputMessageFacade()
        # self.__direction = InputDirectionFacade()
        self.__message = InputValue(message='Input Text')
        self.__custom_symbol = InputValue(message='Input Text')
        self._height = InputValue(message='Input height')
        self._width = InputValue(message='Input width')
        self._direction = InputValue(message='Input direction')
        self._justify = InputValue(message='Input justify')
        self._font = InputValue(message='Input font')
        self._color = InputValue(message='Input color')
        self.__menu_builder = ComplexCommand()

    def run(self):

        self.__menu_builder.add_command((InputTextCommand(self.__message)))  # input message
        # self.__menu_builder.add_command((SelectObjectWithDictCommand(self._color, COLORS)))  # select color
        # self.__menu_builder.add_command((ArtSetMessageCommand(self._art)))  # select font
        # self.__menu_builder.add_command((ArtSetMessageCommand(self._art)))  # select justify
        self.__menu_builder.add_command((InputTextCommand(self.__custom_symbol)))  # select custom symbol
        self.__menu_builder.add_command((ArtScalingCommand(self._art)))  # select SIZE
        # self.__menu_builder.add_command((ArtSetMessageCommand(self._art)))  # preview(create)
        self.__menu_builder.run()
        print(self._art.create_art())
        self.__menu_builder.add_command((ArtSetMessageCommand(self._art)))  # save
        self.__menu_builder.run()

        """
        ввести текст
        Вибір шрифту
        Вибір кольору
        форматування виводу
        збереження
        розмір
        вибір символів
        функція попереднього перегляду    
        """


        # self.__menu_builder.add_command(InputTextCommand(self.__message))
        # self._art.message = self.__message.value
        #
        # if input("Do you want to do direction(1/0): ") == '1':
        #     self.__menu_builder.add_command(InputTextCommand(self._direction))
        #     self._art.direction = self._direction.value
        #
        # if input("Do you want to do justify(1/0): ") == '1':
        #     self.__menu_builder.add_command(InputTextCommand(self._justify))
        #     self._art.justify = self._justify.value
        #
        # if input("Do you want to do font(1/0): ") == '1':
        #     self.__menu_builder.add_command(InputTextCommand(self._font))
        #     self._art.font = self._font.value
        #
        # if input("Do you want to do color(1/0): ") == '1':
        #     self.__menu_builder.add_command(InputTextCommand(self._color))
        #
        # if input("Do you want to do scaling(1/0): ") == '1':
        #     self.__menu_builder.add_command(InputTextCommand(self._height))
        #     self.__menu_builder.add_command(InputTextCommand(self._width))
        #     self._art.height = self._height.value
        #     self._art.width = self._width.value
        #     self.__menu_builder.add_command(ArtScalingCommand(self._art))
        # else:
        #     self.__menu_builder.add_command(ArtCreateCommand(self._art))

        # self.__menu_builder.run()
        #
        # print(self._art.create_art())
        # art = ArtGenerator(message=self.__message.value, height=self._height.value, width=self._width.value,
        #                    direction=self._direction.value, justify=self._justify.value, font=self._font.value)
        # print(self._art._ascii_art)

menu = MenuLabOne()

menu.run()
