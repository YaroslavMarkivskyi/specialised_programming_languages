from Shared.Console.UserInput.Command.InputBoolCommand import InputBoolCommand
from Shared.Console.UserInput.InputValue import InputValue
from Shared.Command.ComplexCommand import ComplexCommand


class InputDirectionFacade:
    def __init__(self):
        self.__direction = InputValue(message='Input Text')
        self.__menu_builder = ComplexCommand()

    def run(self):
        self.__menu_builder.add_command(InputBoolCommand(self.__direction))
        self.__menu_builder.run()
        return self.__direction.value
