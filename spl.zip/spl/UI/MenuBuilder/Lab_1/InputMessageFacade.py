from Shared.Console.UserInput.Command.InputTextCommand import InputTextCommand
from Shared.Console.UserInput.InputValue import InputValue
from Shared.Command.ComplexCommand import ComplexCommand


class InputMessageFacade:
    def __init__(self):
        self.__message = InputValue(message='Input Text')
        self.__menu_builder = ComplexCommand()

    def run(self):
        self.__menu_builder.add_command(InputTextCommand(self.__message))
        self.__menu_builder.run()
        return self.__message.value
