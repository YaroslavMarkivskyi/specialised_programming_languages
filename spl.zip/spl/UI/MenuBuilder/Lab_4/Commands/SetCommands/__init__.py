from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetFontCommand import ArtSetFontCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetHeightCommand import ArtSetHeightCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetJustifyCommand import ArtSetJustifyCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetMessageCommand import ArtSetMessageCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetSymbolCommand import ArtSetSymbolCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetSymbolCommand import ArtSetSymbolCommand
from UI.MenuBuilder.Lab_4.Commands.SetCommands.ArtSetWidthCommand import ArtSetWidthCommand
