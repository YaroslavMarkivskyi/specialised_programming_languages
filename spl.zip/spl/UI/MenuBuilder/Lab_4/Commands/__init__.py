from UI.MenuBuilder.Lab_4.Commands.MethodCommands import *
from UI.MenuBuilder.Lab_4.Commands.SetCommands import *
