from UI.MenuBuilder.Lab_4.Commands.MethodCommands.ArtCreateCommand import ArtCreateCommand
from UI.MenuBuilder.Lab_4.Commands.MethodCommands.ArtCustomFontCommand import ArtCustomFontCommand
from UI.MenuBuilder.Lab_4.Commands.MethodCommands.ArtScalingCommand import ArtScalingCommand

