from Shared.Command.Command import Command
from Classes.lab_5.Figure import Figure


class SetParamsCommand(Command):
    """
    Command can implement create art .
    """

    def __init__(self, executor: Figure, params: dict):
        self.__executor = executor
        self.__params = params

    def execute(self) -> None:
        self.__executor.params = self.__params
