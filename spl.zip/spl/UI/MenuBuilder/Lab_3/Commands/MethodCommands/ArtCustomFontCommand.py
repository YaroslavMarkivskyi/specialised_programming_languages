from Shared.Command.Command import Command
from Classes.lab_3.ArtGenerator import ArtGenerator


class ArtCustomFontCommand(Command):
    """
    Command can implement custom art .
    """

    def __init__(self, executor: ArtGenerator):
        self.__executor = executor

    def execute(self) -> None:
        self.__executor.custom_font()
