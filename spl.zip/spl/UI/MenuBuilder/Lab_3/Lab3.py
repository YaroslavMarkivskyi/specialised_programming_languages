from Classes.lab_3 import *
from Shared.BuilderMenu.BuilderMenu import BuilderMenu
from Commands import *

from Shared.Console.Input import InputValue, InputTextCommand, SelectObjectWithDictCommand, SetInputMessageCommand, \
    InputIntNumberCommand, InputBoolCommand
from Shared.Constants import COLORS, FONTS_TYPE

from Shared.StylizeSymbol import SetColorCommand


class MenuLab3(BuilderMenu):
    def __init__(self):
        super().__init__()
        self._ascii_art = ArtGenerator()
        self._message = InputValue(message='Input message')
        self._height = InputValue(message='Input height')
        self._width = InputValue(message='Input width')
        self._justify = InputValue(message='Input direction')
        self._font = InputValue(message='Input font')
        self._color = InputValue(message='Input color')
        self._symbol = InputValue(message='Input symbol')
        self._subsystem_status = InputValue(message='Do you want to set scaling(1/0:)')
        self._font_type = InputValue(message="Choose parameters")

    def _configure_lab_subsystem(self):
        self._configure_message_subsystem()
        self._configure_justify_subsystem()
        self._configure_font_subsystem()
        self._configure_scaling_subsystem()
        self._configure_color_subsystem()

    def _convert_obj_to_result_subsystem(self):
        self._result = self._ascii_art.__str__()

    def _configure_message_subsystem(self):
        self._menu_builder.instant_command(InputTextCommand(self._message))
        self._menu_builder.instant_command(ArtSetMessageCommand(self._ascii_art, self._message.value))

    def _configure_justify_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self._justify, JUSTIFIES))
        self._menu_builder.instant_command(ArtSetJustifyCommand(self._ascii_art, self._justify.value))

    def _configure_font_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self._font_type, FONTS_TYPE))
        if self._font_type.value == 'Base Fonts':
            self._configure_base_font_subsystem()
        elif self._font_type.value == 'Custom font':
            self._configure_custom_font_subsystem()

    def _configure_base_font_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self._font, FONTS))
        self._menu_builder.instant_command(ArtSetFontCommand(self._ascii_art, self._font.value))
        self._menu_builder.instant_command((ArtCreateCommand(self._ascii_art)))

    def _configure_custom_font_subsystem(self):
        self._menu_builder.instant_command(InputTextCommand(self._symbol))
        self._menu_builder.instant_command(ArtSetSymbolCommand(self._ascii_art, self._symbol.value))
        self._menu_builder.instant_command(ArtCustomFontCommand(self._ascii_art))

    def _configure_color_subsystem(self):
        self._menu_builder.instant_command(SelectObjectWithDictCommand(self._color, COLORS))
        self._menu_builder.instant_command(SetColorCommand(self._stylize_symbols, self._color.value))

    def _configure_check_subsystem(self):
        self._menu_builder.instant_command(SetInputMessageCommand(self._subsystem_status,
                                                                  "Do you want to set scaling(1/0:)"))
        self._menu_builder.instant_command(InputBoolCommand(self._subsystem_status))

    def _configure_scaling_subsystem(self):
        if self._subsystem_status.value:
            self._menu_builder.instant_command(InputIntNumberCommand(self._width))
            self._menu_builder.instant_command(InputIntNumberCommand(self._height))
            self._menu_builder.instant_command((ArtSetWidthCommand(self._ascii_art, self._width.value)))
            self._menu_builder.instant_command((ArtSetHeightCommand(self._ascii_art, self._height.value)))
            self._menu_builder.instant_command(ArtScalingCommand(self._ascii_art))


menu_facade = MenuLab3()
menu_facade.run_menu()
