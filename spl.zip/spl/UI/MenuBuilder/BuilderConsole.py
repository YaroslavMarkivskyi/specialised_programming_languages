

class BuilderConsole:
    obj = None
    errors = ()
    mess_config = {}
    advanced = None

    def __init__(self, **kwargs):
        if 'obj' in kwargs:
            self.obj = kwargs['obj']
        if 'errors' in kwargs:
            self.errors = kwargs['errors']
        if 'mess_config' in kwargs:
            self.mess_config = dict(kwargs['mess_config'])
        if 'advanced' in kwargs:
            self.advanced = kwargs['advanced']

    def configuration(self):
        output_config = {}
        for key, value in self.mess_config.items():
            user_value = input(f'{value}')
            output_config[key] = user_value
        return output_config

    def cycle(self):
        stop = ''
        while stop != 'f':
            try:
                config = self.configuration()
                obj = self.obj(**config)
                print(obj)
                if self.advanced:
                    obj.run()
            except self.errors as e:
                print(f"Error: {e}")
            finally:
                stop = input("Press 'f' if you want to exit: ")

    def run(self):
        if self.advanced:
            if self.mess_config:
                self.cycle()
            else:
                obj = self.obj()
                obj.run()
        else:
            self.cycle()
