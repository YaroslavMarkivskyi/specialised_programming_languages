
from UI.MenuBuilder.BuilderConsole import BuilderConsole
from UI.Menu.Menu import menu


def main():
    print("Menu: ")
    while True:
        dict_unpack(menu)
        user_input = input("Select Lab #: ")
        current = menu.get(user_input, None)
        if current is not None and current.__str__() != 'EXIT':
            try:
                config = current.config()
                builder_console = BuilderConsole(**config)
                builder_console.run()
            except AttributeError:
                continue
        elif current.__str__() == 'EXIT':
            break
        else:
            print("\nIncorrect select\n")


def dict_unpack(dictionary: dict) -> None:
    for key, value in dictionary.items():
        print(key, value)


def get_dict_value(dictionary: dict, value: object) -> object:
    return dictionary.get(value)

# def run_console_builder(obj: object) -> None:
#     try:
#         config = current.config()
#         builder_console = BuilderConsole(**config)
#         builder_console.run()
#     except AttributeError:
#         continue