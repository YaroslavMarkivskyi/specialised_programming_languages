from UI.MenuBuilder import menu_lab_1, menu_lab_2, menu_lab_3, menu_lab_4, menu_lab_5, menu_lab_6, menu_lab_7, \
    menu_lab_8, menu_exit


menu = {
    '1': menu_lab_1.__str__(),
    '2': menu_lab_2.__str__(),
    '3': menu_lab_3.__str__(),
    '4': menu_lab_4.__str__(),
    '5': menu_lab_5.__str__(),
    '6': menu_lab_6.__str__(),
    '7': menu_lab_7.__str__(),
    '8': menu_lab_8.__str__(),
    '9': menu_exit.__str__(),
}


